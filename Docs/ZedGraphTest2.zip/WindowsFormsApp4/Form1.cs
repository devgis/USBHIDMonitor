﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZedGraph;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // get a reference to the GraphPane
            
            GraphPane myPane = zedGraphControl1.GraphPane;
            // Set the Titles
            myPane.Title.Text = "My Test Graph";
            myPane.XAxis.Title.Text = "My X Axis";
            myPane.YAxis.Title.Text = "My Y Axis";
            // Make up some data arrays based on the Sine function
            double x, y1, y2;
            PointPairList list1 = new PointPairList();
            PointPairList list2 = new PointPairList();
            for (int i = 0; i < 36; i++)
            {
                x = (double)i + 5;
                y1 = 1.5 + Math.Sin((double)i * 0.2);
                y2 = 3.0 * (1.5 + Math.Sin((double)i * 0.2));
                list1.Add(x, y1);
                list2.Add(x, y2);
            }
            // Generate a red curve with diamond
            // symbols, and "Porsche" in the legend
            LineItem myCurve = myPane.AddCurve("Porsche",
             list1, Color.Red, SymbolType.Diamond);
            // Generate a blue curve with circle
            // symbols, and "Piper" in the legend
            LineItem myCurve2 = myPane.AddCurve("Piper",
             list2, Color.Blue, SymbolType.Circle);
            // Tell ZedGraph to refigure the
            // axes since the data have changed



            //            //myCurve.Points[0].Clone = 33;
            //            CurveItem nearstCurve;
            //            int j;

            //            double x2, y;
            //            myPane.ReverseTransform(myCurve.Points[1], out x2, out y);
            //            PointF mousePt = new PointF((float)x2, (float)y);
            //            zedGraphControl1.GraphPane.FindNearestPoint(mousePt, out nearstCurve, out j);
            //            if (nearstCurve != null && nearstCurve.Points[j] != null)
            //            {
            //                nearstCurve.AddPoint(0, 0);

            //                ArrowObj myArrow = new ArrowObj(Color.FromArgb(0xA0, 0x00, 0x00), 20, j+1, zedGraphControl1.GraphPane.YAxisList[0].Scale.Min, j+1,

            //zedGraphControl1.GraphPane.YAxisList[0].Scale.Max);
            //                myArrow.Line.Style = System.Drawing.Drawing2D.DashStyle.Dash;
            //                myArrow.Line.DashOff = 1;
            //                myArrow.Line.DashOn = 1;
            //                myArrow.ZOrder = ZOrder.B_BehindLegend;

            //                zedGraphControl1.GraphPane.GraphObjList.Clear();
            //                zedGraphControl1.GraphPane.GraphObjList.Add(myArrow);

            //            }

            var clor = Color.FromArgb(0xA0, 0x00, 0x00);
            EllipseObj myobje = new EllipseObj((float)myCurve.Points[0].X-0.25, (float)myCurve.Points[0].Y+0.125, 0.5, 0.25, clor, clor);
            myobje.ZOrder = ZOrder.B_BehindLegend;

            //ArrowObj myArrow = new ArrowObj(Color.FromArgb(0xA0, 0x00, 0x00), 20, (float)myCurve.Points[0].X, (float)myCurve.Points[0].X, (float)myCurve.Points[0].Y,(float)myCurve.Points[0].Y);
            //myArrow.Line.Style = System.Drawing.Drawing2D.DashStyle.Dash;
            //myArrow.Line.DashOff = 1;
            //myArrow.Line.DashOn = 1;
            //myArrow.ZOrder = ZOrder.B_BehindLegend;

            zedGraphControl1.GraphPane.GraphObjList.Clear();
            zedGraphControl1.GraphPane.GraphObjList.Add(myobje);

            zedGraphControl1.AxisChange();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            zedGraphControl1.GraphPane.GraphObjList.Clear();
            zedGraphControl1.Refresh();
            //zedGraphControl1.AxisChange();
        }
    }
}
